if('IntersectionObserver' in window)document.documentElement.className+=' js';
