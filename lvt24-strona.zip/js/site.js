(function(){var d=document,sc=d.currentScript||{dataset:{}};var LANG=sc.dataset.lang||'pl',THANKS=sc.dataset.thanks||'',SENDING=sc.dataset.sending||'',FAIL=sc.dataset.fail||'',GA=window.LVT_GA||'',EP=window.LVT_FORM||'https://formsubmit.co/ajax/lvt24.kontakt@gmail.com';
function qa(s,c){return Array.prototype.slice.call((c||d).querySelectorAll(s))}
qa('form[data-fs]').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();if(f.querySelector('[name=_honey]').value)return;var b=f.querySelector('button[type=submit]'),s=f.querySelector('.status');b.disabled=true;s.textContent=SENDING;
fetch(EP,{method:'POST',headers:{'Accept':'application/json'},body:new FormData(f)}).then(function(r){return r.json()}).then(function(j){if(j&&(j.success===true||j.success==='true')){if(window.gtag)gtag('event','generate_lead');location.href=THANKS}else throw 0}).catch(function(){b.disabled=false;s.textContent=FAIL;var fd=new FormData(f),t=[];fd.forEach(function(v,k){if(k.charAt(0)!=='_'&&v)t.push(k+': '+v)});location.href='mailto:lvt24.kontakt@gmail.com?subject='+encodeURIComponent(fd.get('_subject'))+'&body='+encodeURIComponent(t.join('\n'))})})});
var mb=d.getElementById('mapbox');if(mb&&/(^|\.)(pomocdrogowalvt24h\.com)$/.test(location.hostname)){var i=d.createElement('iframe');i.src='https://www.google.com/maps?q=Przejazdowa+21,+Wroc%C5%82aw&output=embed&hl='+LANG;i.title='Przejazdowa 21, Wrocław';i.loading='lazy';i.referrerPolicy='no-referrer-when-downgrade';mb.innerHTML='';mb.appendChild(i)}
var rb=d.querySelector('.ribbon'),tr=rb&&rb.querySelector('.track');
if(tr){var set=qa('figure',tr);for(var k=0;k<2;k++)set.forEach(function(f){var c=f.cloneNode(true);c.setAttribute('aria-hidden','true');var im=c.querySelector('img');if(im)im.alt='';tr.appendChild(c)});
var pos=0,paused=false,t0,w=function(){return tr.scrollWidth/3};
function norm(v){var x=w();while(v>=2*x)v-=x;while(v<x)v+=x;return v}
function pause(){paused=true;clearTimeout(t0)}function resume(){clearTimeout(t0);t0=setTimeout(function(){pos=rb.scrollLeft;paused=false},2200)}
['pointerdown','touchstart','mouseenter','focusin'].forEach(function(ev){rb.addEventListener(ev,pause,{passive:true})});
['pointerup','touchend','touchcancel','mouseleave','focusout'].forEach(function(ev){rb.addEventListener(ev,resume,{passive:true})});
rb.addEventListener('wheel',function(){pause();resume()},{passive:true});
rb.addEventListener('scroll',function(){if(!paused)return;var n=norm(rb.scrollLeft);if(Math.abs(n-rb.scrollLeft)>1)rb.scrollLeft=n;pos=rb.scrollLeft},{passive:true});
rb.scrollLeft=pos=w();
(function step(){if(!paused){pos+=.5;pos=norm(pos);rb.scrollLeft=pos}requestAnimationFrame(step)})()}
var dl=d.getElementById('gdlg');if(dl){var imgs=qa('.ggrid img',dl),cur=0,gv=d.getElementById('gview'),gi=d.getElementById('gvi');
function show(i){cur=(i+imgs.length)%imgs.length;gi.src=imgs[cur].src;gi.alt=imgs[cur].alt;gv.classList.add('on')}
d.getElementById('gal-all').addEventListener('click',function(){imgs.forEach(function(im){if(!im.getAttribute('src'))im.src=im.getAttribute('data-src')});if(dl.showModal)dl.showModal();else dl.setAttribute('open','')});
d.getElementById('gclose').addEventListener('click',function(){dl.close()});
qa('.ggrid button',dl).forEach(function(b,i){b.addEventListener('click',function(){show(i)})});
d.getElementById('gvx').onclick=function(){gv.classList.remove('on')};d.getElementById('gvp').onclick=function(){show(cur-1)};d.getElementById('gvn').onclick=function(){show(cur+1)};
dl.addEventListener('cancel',function(e){if(gv.classList.contains('on')){e.preventDefault();gv.classList.remove('on')}});
dl.addEventListener('close',function(){gv.classList.remove('on')});
dl.addEventListener('keydown',function(e){if(!gv.classList.contains('on'))return;if(e.key==='ArrowLeft')show(cur-1);if(e.key==='ArrowRight')show(cur+1)});
dl.addEventListener('click',function(e){if(e.target===dl)dl.close()})}
if(/\bjs\b/.test(d.documentElement.className)){var els=qa('main h2,main .lead,.tile,.wi,.panel,.card,.stars,.ribbon,.case,.faq details');
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
els.forEach(function(el){el.classList.add('rv');var sib=Array.prototype.filter.call(el.parentElement.children,function(c){return c.tagName===el.tagName&&c.className.split(' ')[0]===el.className.split(' ')[0]});el.style.setProperty('--d',(Math.max(0,sib.indexOf(el))*.1)+'s');io.observe(el)})}
var CC=d.getElementById('cc');
function loadGA(){var s=d.createElement('script');s.async=1;s.src='https://www.googletagmanager.com/gtag/js?id='+GA;d.head.appendChild(s);window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments)};gtag('js',new Date());gtag('config',GA,{anonymize_ip:true})}
if(GA&&GA.indexOf('XXXX')<0){var c=null;try{c=localStorage.getItem('lvt_cc')}catch(e){}
if(c==='1')loadGA();else if(!c&&CC)CC.hidden=false;
if(CC)qa('button',CC).forEach(function(b){b.addEventListener('click',function(){var y=b.dataset.y==='1';try{localStorage.setItem('lvt_cc',y?'1':'0')}catch(e){}CC.hidden=true;if(y)loadGA()})})}if(location.pathname.indexOf('thanks')>-1&&window.gtag)gtag('event','generate_lead');
})();
