// Ustawienia strony.
// Wstaw swoj identyfikator Google Analytics w miejsce G-XXXXXXXXXX (baner cookies pojawi sie dopiero wtedy).
window.LVT_GA="G-XXXXXXXXXX";
// Adres wysylki formularzy (powiadomienia trafiaja na ten e-mail).
window.LVT_FORM="https://formsubmit.co/ajax/lvt24.kontakt@gmail.com";
